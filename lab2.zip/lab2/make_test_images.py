"""Генератор тестовой базы изображений для ЛР №2 (вариант 7:
глобальная пороговая обработка + низкочастотные фильтры).

Для каждой картинки сохраняется эталонная маска объектов (папка ground_truth),
чтобы можно было посчитать точность сегментации.
Запуск: python make_test_images.py
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 400, 300
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_images")
GT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ground_truth")
os.makedirs(OUT, exist_ok=True)
os.makedirs(GT, exist_ok=True)


def scene_mask(kind="normal"):
    """Маска объектов: True = объект."""
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    if kind == "small":
        # маленькие объекты (~2-3% площади)
        d.ellipse((60, 60, 90, 90), fill=255)
        d.rectangle((250, 180, 285, 205), fill=255)
        d.ellipse((330, 40, 352, 62), fill=255)
    else:
        d.ellipse((40, 40, 190, 180), fill=255)
        d.rectangle((230, 60, 360, 150), fill=255)
        d.polygon([(70, 230), (170, 200), (200, 280), (90, 285)], fill=255)
        d.ellipse((260, 190, 350, 270), fill=255)
        d.text((215, 20), "LAB 2 TEXT", fill=255)
    return np.array(m) > 0


def render(mask, bg, fg, bg_sigma=0.0, fg_sigma=0.0):
    img = np.where(mask, fg, bg).astype(np.float64)
    img += rng.normal(0, 1, img.shape) * np.where(mask, fg_sigma, bg_sigma)
    return img


def save(name, img, mask):
    arr = np.clip(img, 0, 255).astype(np.uint8)
    Image.fromarray(arr).save(os.path.join(OUT, name + ".png"))
    Image.fromarray((mask * 255).astype(np.uint8)).save(os.path.join(GT, name + "_mask.png"))


def blur(img, r):
    im = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    return np.array(im.filter(ImageFilter.GaussianBlur(r))).astype(np.float64)


m = scene_mask()
ms = scene_mask("small")

# 1. Чистое бимодальное изображение (эталон «лёгкого» случая)
save("01_clean", render(m, 60, 190), m)

# 2. Сильный гауссов шум — гистограммы классов перекрываются, нужно сглаживание
save("02_noise_gauss", render(m, 90, 160, 40, 40), m)

# 3. Гауссов + импульсный шум (соль-перец)
img = render(m, 80, 180, 25, 25)
sp = rng.random(img.shape)
img[sp < 0.03] = 0
img[sp > 0.97] = 255
save("03_noise_saltpepper", img, m)

# 4. Размытое изображение
save("04_blur", blur(render(m, 60, 190, 6, 6), 3.0), m)

# 5. Малоконтрастное изображение с шумом
save("05_lowcontrast", render(m, 110, 140, 6, 6), m)

# 6. Малый объект на большом фоне + шум (классы очень неравны по размеру)
save("06_small_objects", render(ms, 70, 170, 28, 28), ms)

# 7. Классы с разным разбросом: узкий тёмный фон и «рыхлый» светлый объект
save("07_unequal_variance", render(m, 70, 175, 7, 38), m)

# 8. Неравномерная освещённость (глобальный порог не справится)
yy, xx = np.mgrid[0:H, 0:W]
grad = (xx / W) * 110 - 40
save("08_uneven_light", np.clip(render(m, 70, 150, 8, 8) + grad, 0, 255), m)

# 9. Малые объекты, светлый фон / тёмные объекты (инверсия полярности)
img = render(ms, 200, 90, 14, 14)
save("09_small_dark_on_light", img, ms)

print("Готово:", len(os.listdir(OUT)), "изображений в", OUT)
